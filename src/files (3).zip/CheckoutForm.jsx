'use client';

import { useState } from 'react';
import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, ChevronDown } from 'lucide-react';
import { useCart } from '@/context/CartContext';

const DELIVERY_FEE = 15;
const PHONE_REGEX = /^01[0125][0-9]{8}$/;

// ⚠ مناطق توصيل وهمية — استبدلها ببيانات مناطق التوصيل الفعلية للفرع عند توفرها.
const DELIVERY_AREAS = [
  'شارع باريس',
  'وسط البلد',
  'حي الجامعة',
  'كوم النور',
  'ميدان السكة',
  'أخرى (وضّح في الملاحظات)',
];

// ⚠ رقم واتساب المطعم وهمي — استبدله بالرقم الفعلي بصيغة دولية بدون '+' أو أصفار بادئة.
const RESTAURANT_WHATSAPP_NUMBER = '201000000000';

export default function CheckoutForm() {
  const { cartItems, cartTotal, clearCart } = useCart();

  const [form, setForm] = useState({
    fullName: '',
    phone: '',
    area: DELIVERY_AREAS[0],
    address: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});
  const [orderPlaced, setOrderPlaced] = useState(false);

  const grandTotal = cartTotal + DELIVERY_FEE;

  const handleChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = () => {
    const nextErrors = {};
    if (!form.fullName.trim()) nextErrors.fullName = 'الاسم مطلوب';
    if (!PHONE_REGEX.test(form.phone.trim())) {
      nextErrors.phone = 'رقم هاتف غير صالح (مثال: 01012345678)';
    }
    if (!form.address.trim()) nextErrors.address = 'العنوان التفصيلي مطلوب';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const buildWhatsAppMessage = () => {
    const lines = [];
    lines.push('*طلب جديد من شامينا المداح*');
    lines.push('');
    lines.push('*الأصناف:*');
    cartItems.forEach((ci) => {
      lines.push(`- ${ci.name} × ${ci.quantity} — ${ci.unitPrice * ci.quantity} ج.م`);
      (ci.options || []).forEach((opt) => {
        lines.push(`   + ${opt.name}${opt.priceModifier > 0 ? ` (${opt.priceModifier} ج.م)` : ''}`);
      });
    });
    lines.push('');
    lines.push(`المجموع الفرعي: ${cartTotal} ج.م`);
    lines.push(`رسوم التوصيل: ${DELIVERY_FEE} ج.م`);
    lines.push(`*الإجمالي الكلي: ${grandTotal} ج.م*`);
    lines.push('');
    lines.push('*بيانات العميل:*');
    lines.push(`الاسم: ${form.fullName}`);
    lines.push(`الهاتف: ${form.phone}`);
    lines.push(`المنطقة: ${form.area}`);
    lines.push(`العنوان: ${form.address}`);
    if (form.notes.trim()) lines.push(`ملاحظات: ${form.notes}`);
    lines.push('');
    lines.push('طريقة الدفع: الدفع عند الاستلام');

    return lines.join('\n');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const message = buildWhatsAppMessage();
    const whatsappUrl = `https://wa.me/${RESTAURANT_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

    clearCart();
    window.open(whatsappUrl, '_blank');
    setOrderPlaced(true);
  };

  return (
    <AnimatePresence mode="wait">
      {orderPlaced ? (
        <motion.div
          key="success"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center"
        >
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="flex h-20 w-20 items-center justify-center rounded-full bg-[#FFC629]"
          >
            <CheckCircle2 size={40} className="text-black" strokeWidth={2.2} />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.4 }}
            className="mt-6 text-[20px] font-bold text-black"
          >
            تم استلام طلبك، شكراً لك!
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.4 }}
            className="mt-2 max-w-xs text-[13px] leading-relaxed text-black/50"
          >
            تم فتح واتساب لتأكيد طلبك مع الفرع مباشرة. سيتواصل معك فريقنا قريباً لتأكيد التفاصيل.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.4 }}
            className="mt-8 w-full max-w-xs"
          >
            <Link
              href="/"
              className="flex w-full items-center justify-center rounded-full bg-[#151310] py-3.5 text-[14px] font-bold text-white"
            >
              العودة للرئيسية
            </Link>
          </motion.div>
        </motion.div>
      ) : cartItems.length === 0 ? (
        <motion.div
          key="empty"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="flex min-h-[60vh] flex-col items-center justify-center gap-3 px-4 text-center"
        >
          <p className="text-[15px] font-semibold text-black/60">السلة فارغة</p>
          <Link href="/menu" className="text-[13px] font-semibold text-[#FFC629] underline">
            تصفح المنيو
          </Link>
        </motion.div>
      ) : (
        <motion.form
          key="form"
          onSubmit={handleSubmit}
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.25 }}
          className="px-4 pb-40 pt-2 md:px-8 md:pb-10 lg:px-12"
        >
          <div className="grid gap-5 md:grid-cols-[1fr_360px] md:items-start">
            {/* عمود بيانات التوصيل */}
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-black">الاسم بالكامل</label>
                <input
                  type="text"
                  value={form.fullName}
                  onChange={handleChange('fullName')}
                  placeholder="مثال: أحمد محمد"
                  className={`w-full rounded-2xl border px-4 py-3 text-[14px] outline-none transition-colors focus:border-[#FFC629] ${
                    errors.fullName ? 'border-red-400' : 'border-black/10'
                  }`}
                />
                {errors.fullName && <p className="mt-1 text-[11px] text-red-500">{errors.fullName}</p>}
              </div>

              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-black">رقم الهاتف</label>
                <input
                  type="tel"
                  inputMode="numeric"
                  dir="ltr"
                  value={form.phone}
                  onChange={handleChange('phone')}
                  placeholder="01012345678"
                  className={`w-full rounded-2xl border px-4 py-3 text-right text-[14px] outline-none transition-colors focus:border-[#FFC629] ${
                    errors.phone ? 'border-red-400' : 'border-black/10'
                  }`}
                />
                {errors.phone && <p className="mt-1 text-[11px] text-red-500">{errors.phone}</p>}
              </div>

              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-black">المنطقة</label>
                <div className="relative">
                  <select
                    value={form.area}
                    onChange={handleChange('area')}
                    className="w-full appearance-none rounded-2xl border border-black/10 bg-white px-4 py-3 text-[14px] outline-none focus:border-[#FFC629]"
                  >
                    {DELIVERY_AREAS.map((area) => (
                      <option key={area} value={area}>
                        {area}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={16}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-black/40"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-black">العنوان التفصيلي</label>
                <textarea
                  value={form.address}
                  onChange={handleChange('address')}
                  rows={3}
                  placeholder="اسم الشارع، رقم العقار، الدور، علامة مميزة..."
                  className={`w-full rounded-2xl border px-4 py-3 text-[14px] outline-none transition-colors focus:border-[#FFC629] ${
                    errors.address ? 'border-red-400' : 'border-black/10'
                  }`}
                />
                {errors.address && <p className="mt-1 text-[11px] text-red-500">{errors.address}</p>}
              </div>

              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-black">ملاحظات (اختياري)</label>
                <textarea
                  value={form.notes}
                  onChange={handleChange('notes')}
                  rows={2}
                  placeholder="مثال: بدون بصل، اتصل قبل الوصول..."
                  className="w-full rounded-2xl border border-black/10 px-4 py-3 text-[14px] outline-none focus:border-[#FFC629]"
                />
              </div>

              <div className="rounded-2xl bg-black/5 px-4 py-3">
                <p className="text-[13px] font-semibold text-black">طريقة الدفع</p>
                <p className="mt-0.5 text-[12px] text-black/50">الدفع عند الاستلام (Cash on Delivery)</p>
              </div>
            </div>

            {/* عمود ملخص الفاتورة */}
            <div className="rounded-2xl bg-white p-4 ring-1 ring-black/5 md:sticky md:top-24">
              <h2 className="text-[14px] font-bold text-black">ملخص الطلب</h2>
              <div className="mt-3 space-y-2">
                {cartItems.map((ci) => (
                  <div key={ci.cartItemId} className="flex items-start justify-between text-[13px]">
                    <span className="text-black/70">
                      {ci.name} × {ci.quantity}
                    </span>
                    <span className="font-semibold text-black">{ci.unitPrice * ci.quantity} ج.م</span>
                  </div>
                ))}
              </div>

              <div className="mt-4 space-y-1.5 border-t border-black/5 pt-3 text-[13px]">
                <div className="flex justify-between text-black/60">
                  <span>المجموع الفرعي</span>
                  <span>{cartTotal} ج.م</span>
                </div>
                <div className="flex justify-between text-black/60">
                  <span>رسوم التوصيل</span>
                  <span>{DELIVERY_FEE} ج.م</span>
                </div>
                <div className="mt-1 flex justify-between border-t border-black/5 pt-2 text-[15px] font-bold text-black">
                  <span>الإجمالي الكلي</span>
                  <span>{grandTotal} ج.م</span>
                </div>
              </div>
            </div>
          </div>

          {/* زر التأكيد — ثابت أسفل الشاشة على الموبايل، ضمن التدفق الطبيعي على الديسكتوب */}
          <div className="fixed inset-x-0 bottom-16 z-40 border-t border-black/5 bg-white px-4 py-3 md:static md:mt-6 md:border-0 md:px-0 md:py-0">
            <button
              type="submit"
              className="w-full rounded-full bg-[#FFC629] py-4 text-[15px] font-bold text-black transition-transform active:scale-[0.98] md:max-w-xs"
            >
              تأكيد الطلب - {grandTotal} ج.م
            </button>
          </div>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
